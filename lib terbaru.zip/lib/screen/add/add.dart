import 'package:flutter/material.dart';

class AddScreen extends StatelessWidget {
  const AddScreen({super.key});

  @override
  Widget build(BuildContext context) {
    //TODO : Impelement build
    return Scaffold(
      body: Center(
        child: Text(
          "Ini Halaman Add",
          style: TextStyle(color: Colors.black, fontSize: 25),
        ),
      ),
    );
  }
}
