import 'package:flutter/material.dart';

class StatisticScreen extends StatelessWidget {
  const StatisticScreen({super.key});

  @override
  Widget build(BuildContext context) {
    //TODO : Impelement build
    return Scaffold(
      body: Center(
        child: Text(
          "Ini Halaman Jelajahi",
          style: TextStyle(color: Colors.black, fontSize: 25),
        ),
      ),
    );
  }
}
